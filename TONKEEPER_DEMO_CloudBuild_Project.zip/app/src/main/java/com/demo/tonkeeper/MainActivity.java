package com.demo.tonkeeper;

import android.app.*;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.text.DecimalFormat;
import java.util.*;

public class MainActivity extends Activity {
    final String[] names={"TON","USDT","BTC","GRAM"};
    final String[] symbols={"💎","💵","₿","🔷"};
    final double[] prices={5.20,1.00,68000.0,0.012};
    double[] balances={125.50,250.00,0.015,4200.0};
    LinearLayout root, assets, history;
    TextView totalText;
    ArrayList<String> entries=new ArrayList<>();
    DecimalFormat df=new DecimalFormat("#,##0.########");

    int bg=Color.rgb(8,10,16), panel=Color.rgb(24,27,36), muted=Color.rgb(145,153,169), white=Color.WHITE, blue=Color.rgb(45,145,255), green=Color.rgb(40,205,135);
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        for(int i=0;i<4;i++) balances[i]=getPreferences(0).getFloat("b"+i,(float)balances[i]);
        for(int i=0;i<20;i++){String e=getPreferences(0).getString("h"+i,null);if(e!=null)entries.add(e);}
        if(entries.isEmpty()) entries.add("Демо-кошелёк создан • Сегодня");
        render();
    }
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void pad(View v,int a){v.setPadding(a,a,a,a);}
    void render(){
        ScrollView scroll=new ScrollView(this); root=vertical();root.setBackgroundColor(bg);root.setPadding(18,16,18,28);scroll.addView(root);setContentView(scroll);
        LinearLayout top=horizontal();TextView logo=text("◈",30,blue);top.addView(logo);TextView brand=text("  TONKEEPER",20,white);brand.setTypeface(null,1);top.addView(brand);top.addView(text("  DEMO",12,blue));top.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));TextView menu=text("⋮",28,white);top.addView(menu);root.addView(top);
        root.addView(text("Ваш демо-баланс",14,muted)); totalText=text(money(total())+" $",34,white);totalText.setTypeface(null,1); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=5;root.addView(totalText,tp);
        TextView note=text("ВИРТУАЛЬНЫЕ АКТИВЫ • НЕ РЕАЛЬНЫЕ СРЕДСТВА",10,blue);note.setLetterSpacing(.07f);root.addView(note);
        LinearLayout actions=horizontal();actions.setGravity(Gravity.CENTER);actions.setPadding(0,20,0,20);
        String[] act={"↗\nОтправить","＋\nПополнить","⇄\nОбменять","✎\nИзменить"};
        for(int i=0;i<4;i++){final int ix=i;TextView a=text(act[i],12,white);a.setGravity(Gravity.CENTER);a.setPadding(5,12,5,12);a.setBackground(shape(panel,18));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,-2,1);ap.setMargins(3,0,3,0);actions.addView(a,ap);a.setOnClickListener(v->{if(ix==3) chooseEdit();else addEntry("Демо-действие: "+new String[]{"Отправка (симуляция)","Пополнение (симуляция)","Обмен (симуляция)"}[ix]);});}
        root.addView(actions);
        LinearLayout title=horizontal();TextView t=text("Мои активы",20,white);t.setTypeface(null,1);title.addView(t);title.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));TextView edit=text("Изменить баланс",12,blue);title.addView(edit);edit.setOnClickListener(v->chooseEdit());root.addView(title);
        assets=vertical();LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.topMargin=10;root.addView(assets,ap);
        for(int i=0;i<4;i++) addAsset(i);
        root.addView(text("Обзор",20,white),marginTop(20));
        TextView chart=text("  ╱╲     ╱╲       ╱╲\n╱    ╲_╱    ╲___╱    ╲",23,green);chart.setGravity(Gravity.CENTER);chart.setBackground(shape(panel,18));chart.setPadding(10,20,10,20);root.addView(chart,marginTop(10));
        LinearLayout htitle=horizontal();TextView ht=text("История операций",20,white);ht.setTypeface(null,1);htitle.addView(ht);htitle.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));TextView clear=text("Очистить",12,blue);htitle.addView(clear);clear.setOnClickListener(v->{entries.clear();saveHistory();render();});root.addView(htitle,marginTop(20));
        history=vertical();root.addView(history,marginTop(8));for(String e:entries){TextView row=text("↓   "+e,13,white);row.setPadding(14,15,14,15);row.setBackground(shape(panel,14));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=7;history.addView(row,rp);}
        TextView footer=text("TONKEEPER DEMO — демонстрационный симулятор. Балансы можно менять вручную. Реальных криптоактивов и переводов нет.",11,muted);footer.setPadding(4,22,4,0);root.addView(footer);
    }
    LinearLayout.LayoutParams marginTop(int n){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=n;return p;}
    double total(){double x=0;for(int i=0;i<4;i++)x+=balances[i]*prices[i];return x;}
    String money(double x){return new DecimalFormat("#,##0.00").format(x);}
    void addAsset(int i){
        LinearLayout card=horizontal();card.setPadding(14,14,14,14);card.setBackground(shape(panel,18));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=8;assets.addView(card,cp);
        TextView icon=text(symbols[i],25,white);icon.setGravity(Gravity.CENTER);icon.setBackground(shape(Color.rgb(37,83,139),50));card.addView(icon,new LinearLayout.LayoutParams(48,48));
        LinearLayout info=vertical();info.setPadding(12,0,0,0);TextView n=text(names[i],16,white);n.setTypeface(null,1);info.addView(n);info.addView(text("Демо-актив",11,muted));card.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout val=vertical();val.setGravity(Gravity.RIGHT);val.addView(text(df.format(balances[i])+" "+names[i],15,white));val.addView(text("≈ "+money(balances[i]*prices[i])+" $",12,muted));card.addView(val);
        card.setOnClickListener(v->editBalance(i));
    }
    void chooseEdit(){String[] opts={"TON","USDT","BTC","GRAM"};new AlertDialog.Builder(this).setTitle("Изменить демо-баланс").setItems(opts,(d,w)->editBalance(w)).setNegativeButton("Отмена",null).show();}
    void editBalance(int i){
        EditText input=new EditText(this);input.setSingleLine(true);input.setInputType(8194);input.setHint("Новая сумма");input.setText(df.format(balances[i]).replace(",", ""));
        new AlertDialog.Builder(this).setTitle("Баланс "+names[i]).setMessage("Укажи новое виртуальное количество "+names[i]).setView(input).setPositiveButton("Сохранить",(d,w)->{try{double old=balances[i],v=Double.parseDouble(input.getText().toString().replace(',','.'));if(v<0)throw new Exception();balances[i]=v;getPreferences(0).edit().putFloat("b"+i,(float)v).apply();addEntry("Баланс "+names[i]+": "+df.format(old)+" → "+df.format(v));render();}catch(Exception e){new AlertDialog.Builder(this).setMessage("Введи корректное неотрицательное число").setPositiveButton("ОК",null).show();}}).setNegativeButton("Отмена",null).show();
    }
    void addEntry(String s){entries.add(0,s+" • "+new java.text.SimpleDateFormat("dd.MM HH:mm",java.util.Locale.getDefault()).format(new Date()));while(entries.size()>20)entries.remove(entries.size()-1);saveHistory();render();}
    void saveHistory(){android.content.SharedPreferences.Editor e=getPreferences(0).edit();for(int i=0;i<20;i++){if(i<entries.size())e.putString("h"+i,entries.get(i));else e.remove("h"+i);}e.apply();}
}