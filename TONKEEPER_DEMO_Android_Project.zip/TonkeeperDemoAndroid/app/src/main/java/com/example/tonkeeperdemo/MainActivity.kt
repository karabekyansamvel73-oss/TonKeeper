package com.example.tonkeeperdemo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DecimalFormat

private val Navy = Color(0xFF101923)
private val Panel = Color(0xFF1B2937)
private val Blue = Color(0xFF35A8F5)
private val Muted = Color(0xFF9EADBC)
private val Green = Color(0xFF4DD6A3)

data class Coin(val symbol: String, val title: String, val tint: Color, val price: Double, val amount: Double)
data class Tx(val label: String, val symbol: String, val amount: Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WalletApp() }
    }
}

@Composable
fun WalletApp() {
    var coins by remember {
        mutableStateOf(listOf(
            Coin("TON", "Toncoin", Color(0xFF35A8F5), 5.0, 1250.0),
            Coin("USDT", "Tether", Color(0xFF26A17B), 1.0, 5000.0),
            Coin("BTC", "Bitcoin", Color(0xFFF7931A), 65000.0, 0.15),
            Coin("GRAM", "Gram", Color(0xFF9B8CFF), 0.02, 25000.0)
        ))
    }
    var transactions by remember { mutableStateOf(listOf(Tx("Демо-пополнение", "TON", 1250.0))) }
    var dialogCoin by remember { mutableStateOf<Coin?>(null) }
    var amountText by remember { mutableStateOf("") }
    var editMode by remember { mutableStateOf(false) }

    val total = coins.sumOf { it.amount * it.price }
    val money = DecimalFormat("#,##0.00")
    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Blue,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
                contentPadding = PaddingValues(top = 22.dp, bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column {
                            Text("TONKEEPER", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp)
                            Text("DEMO WALLET", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                        }
                        Surface(color = Color(0xFF173B35), shape = RoundedCornerShape(50)) {
                            Text("DEMO", color = Green, modifier = Modifier.padding(horizontal = 13.dp, vertical = 6.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                item {
                    Surface(color = Panel, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(22.dp)) {
                            Text("Общий виртуальный баланс", color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("$${money.format(total)}", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                            Text("Демонстрационные средства · не криптовалюта", color = Muted, fontSize = 11.sp)
                            Spacer(Modifier.height(20.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                ActionButton("Пополнить", Icons.Default.Add, Modifier.weight(1f)) { dialogCoin = coins.first(); amountText = "" }
                                ActionButton("Изменить", Icons.Default.Edit, Modifier.weight(1f)) { editMode = !editMode }
                            }
                        }
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Мои активы", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text(if (editMode) "Выбери актив" else "Изменить баланс", color = Blue, fontSize = 12.sp, modifier = Modifier.clickable { editMode = !editMode })
                    }
                }
                items(coins.size) { index ->
                    val coin = coins[index]
                    Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().clickable { dialogCoin = coin; amountText = coin.amount.toString() }) {
                        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(42.dp).background(coin.tint, CircleShape), contentAlignment = Alignment.Center) {
                                Text(coin.symbol.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(coin.title, color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text(coin.symbol, color = Muted, fontSize = 12.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("${money.format(coin.amount)} ${coin.symbol}", color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text("$${money.format(coin.amount * coin.price)}", color = Muted, fontSize = 12.sp)
                            }
                        }
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.History, null, tint = Blue)
                        Spacer(Modifier.width(8.dp))
                        Text("История операций", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    }
                }
                items(transactions.size) { i ->
                    val tx = transactions[i]
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (tx.amount >= 0) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, null, tint = Green)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tx.label, color = Color.White)
                            Text(tx.symbol, color = Muted, fontSize = 11.sp)
                        }
                        Text("${if (tx.amount >= 0) "+" else ""}${money.format(tx.amount)}", color = if (tx.amount >= 0) Green else Color(0xFFFF8A80))
                    }
                }
                item {
                    Text("Это независимый симулятор. Он не связан с официальным Tonkeeper, не подключается к блокчейну и не подтверждает наличие реальных средств.", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }

    dialogCoin?.let { selected ->
        AlertDialog(
            onDismissRequest = { dialogCoin = null },
            title = { Text("Баланс ${selected.symbol}") },
            text = {
                Column {
                    Text("Введи новое количество виртуальных монет:", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = amountText, onValueChange = { amountText = it },
                        label = { Text("Количество ${selected.symbol}") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true
                    )
                    Text("Изменение сохранится в текущем запуске приложения.", color = Muted, fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val value = amountText.replace(',', '.').toDoubleOrNull()
                    if (value != null && value >= 0) {
                        val old = coins.first { it.symbol == selected.symbol }.amount
                        coins = coins.map { if (it.symbol == selected.symbol) it.copy(amount = value) else it }
                        transactions = listOf(Tx("Ручное изменение баланса", selected.symbol, value - old)) + transactions
                        dialogCoin = null
                    }
                }) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { dialogCoin = null }) { Text("Отмена") } }
        )
    }
}

@Composable
fun ActionButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = modifier.height(48.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue)) {
        Icon(icon, null, modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 12.sp)
    }
}
